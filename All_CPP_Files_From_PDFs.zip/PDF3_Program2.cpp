#include<iostream> 
using namespace std; 
int main (){ 
​
int row , col;  
​
cout<<" enter row of matrix : "; 
​
cin>> row; 
​
cout<< " enter column of matrix : "; 
​
cin >> col; 
​
int M[row][col]; 
​
for( int i = 0 ; i < row ; i++){ 
​
​
for( int j =0 ; j < col ; j++){ 
​
​
​
cout<<" index [ "<<i<<" ][ "<<j<<"]"; 
​
​
​
cin>>M[i][j]; 
​
​
} 
​
} 
​
for( int i = 0 ; i < row ; i++){ 
​
​
​
cout<<" "; 
​
​
for( int j =0 ; j < col ; j++){ 
​
​
​
cout<<M[i][j]<<" "; 
​
​
} 
​
​
cout<<endl; 
​
} 
}