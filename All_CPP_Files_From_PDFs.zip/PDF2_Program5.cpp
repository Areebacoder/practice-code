#include<iostream> 
using namespace std; 
void findVowel(char word[]); 
int main() 
{ 
​
char word[30]; 

​
cin.getline(word, 30); 
​
findVowel(word); 
​
 
​
 
​
 
​
return 0; 
} 
 
void findVowel(char word[]) 
{ 
​
for(int i=0; word[i]!='\0'; i++) 
​
{ 
​
​
if(word[i]=='a'||word[i]=='e'||word[i]=='i'||word[i]=='o'||word[i]=='u'||word[i]=='A'||word[i]=='E'||word[i]=='I'||word[i]
=='O'||word[i]=='U') 
​
​
{ 
​
​
​
cout<<word[i]<<"  "; 
​
​
} 
​
} 
 
}