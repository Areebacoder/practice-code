#include<iostream> 
using namespace std; 
int wordLength(char word[]) 
{ 
    int count = 0; 
    while(word[count] != '\0') 
    { 
        count++; 
    } 
    return count; 
} 
int main() 
{ 
    char word[50]; 
    cout << "Enter a word: "; 
    cin >> word; 
    int length = wordLength(word); 
    cout << "Length of the word is: " << length; 
}