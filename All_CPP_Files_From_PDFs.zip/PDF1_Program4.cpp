#include<iostream> 
using namespace std; 
double volt( double current , double resistance){ 
 
return current * resistance; 
} 
 
int main(){ 
 
double current ; 
 
double resistance ; 
 
cout<< " enetr the current : "; 
 
cin>> current ; 
 
cin.ignore(); 
 
cout<< " enter the resistance : "; 
 
cin>> resistance ; 
 
double voltage = volt( current , resistance ); 

 
cout<< " voltage : "<< voltage ; 
}