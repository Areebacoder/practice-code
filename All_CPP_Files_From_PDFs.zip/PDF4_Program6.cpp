#include<iostream> 
using namespace std; 
 
void reverseWord(char word[], int size) 
{ 
    for(int i=0; i<size/2; i++) 
    { 
        char temp = word[i]; 
        word[i] = word[size-1-i]; 
        word[size-1-i] = temp; 
    } 
} 
int main() 
{ 
    char word[50]; 
    cout<<" Enter Word : "; 
    cin >> word; 
​
int size = 0; 
​
for(int i=0; word[i] != '\0'; i++) 
    { 
    size++; 
    }​
 
    reverseWord(word, size); 
    cout << "Reversed Word: " << word; 
}