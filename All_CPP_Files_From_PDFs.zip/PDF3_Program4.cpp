#include <iostream> 
 
using namespace std; 
 
double strike( float run , float ball){ 
​
double strike; 
​
if( ball!=0){ 
​
​
strike = (run / ball )* 100; 
​
} 
​
return strike; 
} 
int main(){ 
​
float run ; 
​
float ball; 
​
cout<<" enter RUNS : "; 
​
cin>>run ; 
​
cout<<" enter BALLS : "; 
​
cin>> ball; 
​
double ss= strike( run , ball); 
​
cout<<" strike : "<< ss; 
}