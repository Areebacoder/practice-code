#include<iostream> 
using namespace std; 
 
int main() 
{ 
    int rows, cols; 
    cout<<" Enter row : "; 
    cin >> rows ; 
    cout<<" Enter columns : "; 
    cin>> cols 
    int arr[row][col]; 
    for(int i=0; i<rows; i++) 
    { 
     for(int j=0; j<cols; j++) 
    { 
​
 cin >> arr[i][j]; 
    } 
​
} 
    int result = arr[0][0]; 
​
for(int i=0; i<rows; i++) 
    { 
    for(int j=0; j<cols; j++) 
    { 
    if(i==0 && j==0) 
    continue; 
    result -= arr[i][j]; 
       } 
    } 
    cout << "Result = " << result; 
}