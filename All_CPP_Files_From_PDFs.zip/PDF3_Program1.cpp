#include <iostream> 
 
using namespace std; 
 
int countEvenNumbers(int arr[], int size) 
 
{ 
 
    int count = 0; 
 
    for(int i = 0; i < size; i++){ 
 
     if( arr[i] % 2 == 0){ 
​
count++; 
  } 
 
 } 
 
    return count; 
 
} 
 
int main() 
 
{ 
 
    int size; 
 
    cout << "Enter Size of Array: "; 
 
    cin >> size; 
 
    int numbers[size]; 
 
    for(int i = 0; i < size; i++) 
 
    { 
 
        cout << "Enter value in index " << i << ": "; 
 
  cin >> numbers[i]; 
 
    } 
 
    int result = countEvenNumbers(numbers, size); 

 
    cout << "Number of Even Numbers in Array: " << result << endl; 
 
    return 0; 
 
}