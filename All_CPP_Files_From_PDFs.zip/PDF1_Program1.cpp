#include<iostream> 
using namespace std; 
double avreage( double number[] , int size ){ 
 
int sum = 0; 
 
for ( int i = 0; i < size ; i++){ 
 
 
sum = sum + number[i]; 
 
} 
 
cout<< " sum of student marks :  "<< sum ; 
 
 
return ( double) sum / size; 
} 
int main  () 
{ 
 
int size ; 
 
double number [size];  
 
cout<< " Enter the Size of array : "; 
 
cin >> size ; 
 
for( int i = 0 ; i<size ; i++){ 
 
 
cout<< " enter the number of studend : "; 
 
 
cin >> number[i];  
 
} 
 
 
cout<< "numbers of students : "<<endl; 
 
for( int i =0 ; i< size ; i++ ){ 
 
 
cout<< number[i] << endl; 
 
} 
 
 
 double aver = avreage(number , size); 

 
 cout<< " /naverage : "<< aver; 
}