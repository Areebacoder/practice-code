#include<iostream> 
using namespace std; 
double low( double number[], int size ){ 
 
double lower = number [0]; 
 
for( int i =0 ; i < size ; i++){ 
 
 
if( number[i] < lower) 
 
 
lower = number[i]; 
 
}  
 
return lower; 
}  
 
double high( double number[], int size ){ 
 
double high = number [0]; 
 
for ( int i =0 ; i < size ; i++){  
 
if ( number [i]> high) 
 
high = number[i]; 
 
} 
 
return high; 
}  
  
int main(){ 
 
int size ; 
 
cout<< " Enter the Size of array : "; 

 
cin >> size ; 
 
double number [size];  
 
for( int i = 0 ; i<size ; i++){ 
 
 
cout<< " enter the number of studend : "; 
 
 
cin >> number[i];  
 
} 
 
 
cout<< "numbers of students : "<<endl; 
 
for( int i =0 ; i< size ; i++ ){ 
 
 
cout<< number[i] << endl; 
 
}  
 
double lower = low(number , size); 
 
double highest = high(number , size); 
 
cout<< " high marks :  "<< highest<< endl; 
 
cout<<" low marks :  "<< lower<<endl; 
 
 
}