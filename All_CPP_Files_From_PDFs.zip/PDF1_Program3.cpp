#include<iostream> 
using namespace std; 
double power( double base , int exponent){ 
 
double mul = 1; 
 
for( int i =0 ; i< exponent ; i++){ 
 
 
mul = mul * base; 
} return mul; 
} 
int main(){ 

 
double  base ; 
 
int exponent; 
 
cout<<" enter the base : "; 
 
cin>> base; 
 
cin.ignore(); 
 
cout<<" enter the exponent : "; 
 
cin>> exponent; 
 
double mul = power( base , exponent ); 
 
cout<< " muliple of base: "<< mul; 
}