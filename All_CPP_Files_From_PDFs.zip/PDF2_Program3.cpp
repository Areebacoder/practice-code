#include<iostream> 
using namespace std; 
double convert( double celsius){ 
​
double fah; 
​
fah= ( celsius * 9/5)+32; 
​
return fah; 
} 
int main (){ 
​
double calsius ; 
​
cout<< " enter temperature in calsius : "; 
​
cin>> calsius; 
​
double tempfah = convert( calsius ); 
​
cout<< " temperature in fahrenhieit : "<< tempfah;  
}