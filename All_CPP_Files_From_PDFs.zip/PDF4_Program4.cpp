#include<iostream> 
using namespace std; 
double getBowlAve(int runs,int wickets) 
{ 
    if(wicketsTaken == 0) 
    return 0.0; 
    return (double)runs / wickets; 
} 
 
int main() 
{ 
    int runs, wickets; 
    cout<<" Enter runs "; 
​
cin >> runs ; 
​
cout<<" Enter wickets "; 
​
cin>> wickets 
    cout << "Bowling Average: "<< getBowlAve(runs, wickets); 
}