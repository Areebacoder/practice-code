#include <iostream> 
using namespace std; 
double sum ( double number [], int size ){ 
​
double sum = 0; 
 ​
 for( int i = 0 ; i< size ; i++){ 
 ​
 ​
sum = sum + number [i]; 
​
  } 
​
  return sum ; 
} 
int main (){ 
​
int size ; 
​
cout<<" enter the size of array : "; 
​
cin >> size; 
​
double number [ size ]; 
​
cout<< " enter the marks of students : "; 
​
for( int i= 0 ; i< size ; i++ ){ 
​
​
cin>> number[i]; 
​
​
 
​
} 
​
cout<< " students marks :\n "<<endl;; 
​
for( int i= 0 ; i < size ; i++){ 
​
​
cout<<number[i]<<endl; 
​
} 
​
double addition = sum( number , size); 
​
cout<< " sum of all students marks : "<< addition; 
}