#include<iostream> 
using namespace std ; 
bool player(char name[8],char target) 
{ 
 
for( int i = 0; i < 8 ; i++){  
 
if ( name[i]== target){ 
 
 return true; 
 
 } 
 
 
}return false; 
} 
int main(){ 
 
 
 
char name[8]= { 'r','b','f','s','h','m','n','h'}; 
 
char target ; 
 
cout<<" enter player initial : "; 
 
cin>> target; 
 
bool find = player( name , target); 
 if ( find ){ 
  
cout<<" player in team "<< find; 
 }  
 else  
 cout<< " player not in team " << find; 
 
 

}