#include <iostream> 
using namespace std; 
int main() 
{ 
​
int row . col; 
​
cout<<" enter row and column : "; 
​
int M1[row][col]; 
​
int M2[row][col]; 
​
int M3[row][col]; 
​
cout<<"enter Value of Matrix 1"<<endl; 
​
for(int i=0; i<row; i++)  
​
{ 
​
for(int j=0; j<col; j++) 
​
{ 
​
cout<<"index ["<<i<<"]["<<j<<"]: "; 
​
​
cin>>M1[i][j]; 
​
} 
​
} 
​
cout<<"enter value of matrix 2"<<endl; 
​
for(int i=0; i<row; i++)   
​
{ 
​
​
for(int j=0; j<col; j++) 
​
​
{ 
​
​
cout<<"index ["<<i<<"]["<<j<<"]: "; 
​
​
cin>>M2[i][j]; 
​
​
} 
​
} 
​
​
cout<<"Matrix 1"<<endl; 
​
for(int i=0; i<row; i++) 
​
{ 
​
cout<<"    "; 
​
for(int j=0; j<col; j++) 
​
​
{ 
​
cout<<M1[i][j]<<"   "; 
​
​
} 
cout<<endl; 
​
} 
cout<<"Matrix 2"<<endl; 
for(int i=0; i<row; i++) 
{ 
cout<<"    "; 
for(int j=0; j<col; j++) 
​
​
{ 
​
cout<<M2[i][j]<<"   "; 
​
​
} 
cout<<endl; 
} 

for(int i=0; i<row; i++) 
​
{ 
for(int j=0; j<col; j++) 
{ 
M3[i][j]= M1[i][j]+M2[i][j]; 
​
} 
} 
cout<<"Matrix after Addition"<<endl; 
for(int i=0; i<row; i++) 
{ 
cout<<"    "; 
for(int j=0; j<col; j++) 
{ 
​
cout<<M3[i][j]<<"   "; 
} 
​
​
cout<<endl; 
​
} 
}